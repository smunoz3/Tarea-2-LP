Sebastián Muñoz 202273534-1

Para ejecutar el programa se necesita tener instalado make (4.3)
y tener gcc (11.4)

Para compilar: make
Para correr el programa: make run
Para elimiar los archivos compilados: make clean
Para usar el Valgrind: make valgrind

Para este programa se creó una funcion adicional FinDelJuego() 
la cual revisa si los tesoros fueron encontrados.